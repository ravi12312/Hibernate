package com.capgemini.client;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Main {
	public static Connection createConnection() throws ClassNotFoundException,
			SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		String dbURL = "jdbc:mysql://localhost:3306/demodb";
		String userName = "root";
		String password = "pass";
		Connection connection = DriverManager.getConnection(dbURL, userName,
				password);
		return connection;

	}

	public static void insertRecord() throws ClassNotFoundException,
			SQLException {
		Connection connection = createConnection();
		System.out.println("Connected Successfully");
		String sql = "insert into Customer Values(5, 'Adithi', 'Pune', 7000.00)";
		Statement statement = connection.createStatement();
		System.out.println("Created Successfully");
		int r = statement.executeUpdate(sql);
		System.out.println(r + "Rows inserted");
		statement.close();
		connection.close();
	}

	public static void updateRecord() throws ClassNotFoundException,
			SQLException {
		Connection connection = createConnection();
		System.out.println("Connected Successfully");
		String sql = "update Customer set c_amt = c_amt + 2000 where c_id = 1";
		Statement statement = connection.createStatement();
		int r = statement.executeUpdate(sql);
		System.out.println(r + "Rows updated");
		statement.close();
		connection.close();
	}

	public static void deleteRecord() throws ClassNotFoundException,
			SQLException {
		Connection connection = createConnection();
		System.out.println("Connected Successfully");
		String sql = "delete from Customer where c_id = 5";
		Statement statement = connection.createStatement();
		int r = statement.executeUpdate(sql);
		System.out.println(r + "Row deleted");
		statement.close();
		connection.close();
	}

	public static void displayAllRecords() throws ClassNotFoundException,
			SQLException {
		Connection connection = createConnection();
		System.out.println("Connected Successfully");
		String sql = "select * from Customer";
		Statement statement = connection.createStatement();
		ResultSet rs = statement.executeQuery(sql);
		while (rs.next()) {
			System.out.println(rs.getInt(1) + "\t" + rs.getString(2) + "\t"
					+ rs.getString(3) + "\t" + rs.getDouble(4));
		}

		rs.close();
		statement.close();
		connection.close();

	}

	public static void displayOneRecords(int id) throws ClassNotFoundException,
			SQLException {
		Connection connection = createConnection();
		System.out.println("Connected Successfully");
		String sql = "select * from Customer where c_id =" + id;
		Statement statement = connection.createStatement();
		ResultSet rs = statement.executeQuery(sql);

		if (rs.next()) {
			System.out.println(rs.getInt(1) + "\t" + rs.getString(2) + "\t"
					+ rs.getString(3) + "\t" + rs.getDouble(4));
		}
		

		rs.close();
		statement.close();
		connection.close();

	}

	public static void main(String[] args) throws ClassNotFoundException,
			SQLException {
		Scanner scanner = new Scanner(System.in);

		System.out.println("1.insert\n2.update\n3.delete\n4.display\n5.one record\n6.return");
		int choice = scanner.nextInt();

		switch (choice) {
		case 1:
			insertRecord();
			main(args);
			break;
		case 2:
			updateRecord();
			main(args);
			break;
		case 3:
			deleteRecord();
			main(args);
			break;
		case 4:
			displayAllRecords();
			main(args);
			break;
		case 5:
			displayOneRecords(3);
			main(args);
			break;
		case 6:
			System.out.println("exit");
			System.exit(0);
			break;
		default:
			break;
		}

	}

}
