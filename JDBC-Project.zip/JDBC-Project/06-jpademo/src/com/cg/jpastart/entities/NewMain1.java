package com.cg.jpastart.entities;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class NewMain1 {

	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = emf.createEntityManager();
		Trip trip = null;
		em.getTransaction().begin();
		
		trip = em.find(Trip.class, 1);
		em.getTransaction().commit();
		System.out.println(trip);
		System.out.println(trip.getInfo());
		em.close();
		emf.close();
		
	}

}
