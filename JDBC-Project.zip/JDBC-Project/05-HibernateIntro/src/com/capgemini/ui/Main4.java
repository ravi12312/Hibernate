package com.capgemini.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.Business.Employee;

//delete the record
public class Main4 {
	public static void main(String[] args) {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = emf.createEntityManager();
		
		Employee e = null;
		e = em.find(Employee.class, 123);
		
		em.getTransaction().begin();
		em.remove(e);
		em.getTransaction().commit();
		em.close();
		emf.close();
	}
}
