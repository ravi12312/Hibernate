package com.capgemini.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.Business.Contact;

public class Main5 {

	public static void main(String[] args) {
		Contact contact1 = new Contact(121, "Niharika", "8179754660");
		Contact contact2 = new Contact(122, "Nikhil", "9701650850");
		Contact contact3 = new Contact(123, "Mounika", "8977635974");
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
//		em.persist(contact1);
//		em.persist(contact2);
//		em.persist(contact3);		
	//	em.getTransaction().commit();
		
		contact3.setPhoneNumber("8074854023");
		em.merge(contact3);
		
		Contact contact4 = null;
		emf = Persistence.createEntityManagerFactory("JPA-PU");
		em = emf.createEntityManager();
		contact4 = em.find(Contact.class, 122);
		
		contact4.setPhoneNumber("8121312189");
		em.merge(contact4);
		System.out.println(contact4.equals(contact2));
		em.close();
		emf.close();
	}

}
