package com.training.client;

public class Test2 extends Test1{
	@Override
	public void f1() {
		
	}
}
