package com.training.client;

public class Test1 {
	public void f1() {
		
	}
}
