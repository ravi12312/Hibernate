package com.training.client;
/**
 * 
 * @author nthoutam
 *
 */
public class Test4 {
	/**
	 * 
	 * @param n number to be compiled for square
	 * @return return square of the number
	 */
	
	
	int square(int n) {
		return n * n;
	}
}
